import Routes from "express";

const SpecificRoom = async (req,res) => {
    const { id } = req.params;




    
    

}






export { SpecificRoom };