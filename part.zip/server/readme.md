JWT_SECRET=jwtsecrete_here
PORT=2024
MONGO_END_POINT=mongodb://127.0.0.1:27017/TheRummyDB
MAIL_EMAIL=mail_for_mailing
APP_PASSWORD=email_password_here